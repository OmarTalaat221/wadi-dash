import React from "react";
import Table from "../table";

function ContactMessagesTableData({ setOpenDelete }) {
  const messages = [
    {
      id: 1,
      name: "John Doe",
      phone: "+11234567890",
      email: "johndoe@example.com",
      message: "Hello, I'm interested in your services!",
      language: "English",
    },
    {
      id: 2,
      name: "Jane Smith",
      phone: "+10987654321",
      email: "janesmith@example.com",
      message: "I would like more information about your tours.",
      language: "Spanish",
    },
    {
      id: 3,
      name: "Ahmed Ali",
      phone: "+971501234567",
      email: "ahmedali@example.ae",
      message: "مرحباً، أريد الاستفسار عن الخدمات.",
      language: "Arabic",
    },
  ];

  const headers = [
    {
      label: "Name",
      dataIndex: "name",
      sort: true,
      search: true,
    },
    {
      label: "Phone",
      dataIndex: "phone",
      sort: true,
      search: true,
    },
    {
      label: "Email",
      dataIndex: "email",
      sort: true,
      search: true,
    },
    {
      label: "Message",
      dataIndex: "message",
      sort: false,
      search: true,
    },
    {
      label: "Language",
      dataIndex: "language",
      sort: true,
      search: true,
    },
    {
      label: "Actions",
      render: ({ row }) => (
        <div className="flex gap-2">
          <button
            onClick={() => setOpenDelete(row)}
            className="bg-red-500 text-white py-1 px-3 rounded hover:bg-red-600 transition"
          >
            Delete
          </button>
        </div>
      ),
      sort: false,
      search: false,
    },
  ];

  return (
    <div className="ContactMessagesTableData TableData">
      <Table title={"Contact Messages"} headers={headers} body={messages} />
    </div>
  );
}

export default ContactMessagesTableData;
