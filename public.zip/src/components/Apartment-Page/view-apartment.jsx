import React from "react";
import { BsArrowLeft } from "react-icons/bs";

function ViewApartment({ apartment, onBack }) {
  return (
    <div className="p-8 bg-white rounded-lg shadow-lg">
     
      <div className="mb-4 flex items-center">
      <button
        onClick={onBack}
        className="bg-blue-500 text-white mx-1 py-2 px-4 rounded hover:bg-blue-600 transition"
      >
        <BsArrowLeft />
      </button>
        <span className="font-semibold">Type: </span>
        {apartment.text}
      </div>
      <div className="mb-4">
        <video src={apartment.img} controls className="w-full max-w-md" />
      </div>
      <div className="mb-4">
        <span className="font-semibold">Description: </span>
        {apartment.description}
      </div>
    </div>
  );
}

export default ViewApartment;
