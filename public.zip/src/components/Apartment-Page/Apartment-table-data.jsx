import React from "react";
import Table from "../table";

const videos = [
  {
    id: 1,
    img: "https://res.cloudinary.com/duovxefh6/video/upload/v1744207769/Apartment_Sawani_at4sni.webm",
    text: "Apartment",
    description:
      "Ideal for individuals or couples, our apartments combine convenience and modern living. These homes are designed for those who appreciate functional layouts, stylish finishes, and top-notch amenities. Enjoy the vibrant energy of the city, with stunning city views, proximity to public transport, and prime locations.",
  },
  {
    id: 2,
    img: "https://res.cloudinary.com/duovxefh6/video/upload/v1744207820/Mansions_Sawani_j3nkoe.webm",
    text: "Mansion",
    description:
      "For those who seek unmatched luxury, our mansions offer a true statement of elegance and opulence.",
  },
  {
    id: 3,
    img: "https://res.cloudinary.com/duovxefh6/video/upload/v1744207842/Penthouse_tpfut4.webm",
    text: "Penthouse",
    description:
      "Live life at the top in one of our exclusive penthouses. These properties offer breathtaking views and expansive private terraces.",
  },
  {
    id: 4,
    img: "https://res.cloudinary.com/duovxefh6/video/upload/v1744207871/Villa_Sawani_hrpmyn.webm",
    text: "Villa",
    description:
      "Enjoy spacious living with one of our luxurious villas offering privacy, comfort, and modern amenities.",
  },
  {
    id: 5,
    img: "https://res.cloudinary.com/duovxefh6/video/upload/v1744207904/Townhouses_Sawani_qof4vc.webm",
    text: "Townhouse",
    description:
      "Ideal for individuals and families who desire more space while staying connected to the neighborhood.",
  },
  {
    id: 6,
    img: "https://res.cloudinary.com/duovxefh6/video/upload/v1744207782/Commercial_vvxd9l.webm",
    text: "Commercial Properties",
    description:
      "Flexible layouts in prime locations suitable for office spaces, retail stores, or warehouses.",
  },
];

function ApartmentTableData({ setOpenDelete, onView, onEdit }) {
  const headers = [
    {
      label: "Type",
      dataIndex: "text",
      sort: true,
      search: true,
    },
    {
      label: "Video",
      render: ({ row }) => (
        <video src={row.img} controls className="w-32 h-auto" />
      ),
      sort: false,
      search: false,
    },
 
    {
      label: "Actions",
      render: ({ row }) => (
        <div className="flex gap-2">
          <button
            onClick={() => onView(row)}
            className="bg-green-500 text-white py-1 px-3 rounded hover:bg-green-600 transition"
          >
            View
          </button>
          <button
            onClick={() => onEdit(row)}
            className="bg-blue-500 text-white py-1 px-3 rounded hover:bg-blue-600 transition"
          >
            Edit
          </button>
          <button
            onClick={() => setOpenDelete(row)}
            className="bg-red-500 text-white py-1 px-3 rounded hover:bg-red-600 transition"
          >
            Delete
          </button>
        </div>
      ),
      sort: false,
      search: false,
    },
  ];

  return (
    <div className="ApartmentTableData">
      <Table title={"Apartment Videos"} headers={headers} body={videos} />
    </div>
  );
}

export default ApartmentTableData;
