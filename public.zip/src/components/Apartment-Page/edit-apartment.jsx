import React from "react";

function EditApartment({ apartment, onBack }) {
  return (
    <div className="p-8 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Edit Apartment</h2>
      <form className="space-y-4">
        <div>
          <label className="block text-gray-700 font-semibold">Type</label>
          <input
            type="text"
            defaultValue={apartment.text}
            className="border px-3 py-2 rounded w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 font-semibold">Video URL</label>
          <input
            type="text"
            defaultValue={apartment.img}
            className="border px-3 py-2 rounded w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 font-semibold">Description</label>
          <textarea
            defaultValue={apartment.description}
            rows="4"
            className="border px-3 py-2 rounded w-full"
          ></textarea>
        </div>
        <div className="flex gap-4">
          <button type="submit" className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 transition">
            Save Changes
          </button>
          <button type="button" onClick={onBack} className="bg-gray-500 text-white py-2 px-4 rounded hover:bg-gray-600 transition">
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}

export default EditApartment;
