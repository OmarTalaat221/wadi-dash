import React from "react";
import Table from "../table";

const teamMembers = [
  {
    id: 1,
    name: "ABDUL BAN",
    job: "Property Consultant",
    img: "https://res.cloudinary.com/dkc5klynm/image/upload/v1742557436/Sawani_Website-20_xwwjeo.webp",
    moreInformation: "Property Consultant" // You can update this with additional info if needed
  },
  {
    id: 2,
    name: "HUZAIFA ZEB",
    job: "Property Consultant",
    img: "https://res.cloudinary.com/dkc5klynm/image/upload/v1742557432/Sawani_Website-19_pyvdfh.webp",
    moreInformation: "Property Consultant"
  },
  {
    id: 3,
    name: "SEHBAN SAWANI",
    job: "Sales Director",
    img: "https://res.cloudinary.com/dkc5klynm/image/upload/v1742557434/Sawani_Website-23_qxkuyy.webp",
    moreInformation: "Sales Director"
  },
  {
    id: 4,
    name: "ELLE GRUEZO",
    job: "Operation Manager",
    img: "https://res.cloudinary.com/dkc5klynm/image/upload/v1742557431/Sawani_Website-22_uvhifs.webp",
    moreInformation: "Operation Manager"
  },
  {
    id: 5,
    name: "KHIZER HAYAT",
    job: "Property Consultant",
    img: "https://res.cloudinary.com/dkc5klynm/image/upload/v1742557435/Sawani_Website-18_ciovif.webp",
    moreInformation: "Property Consultant"
  },
  {
    id: 6,
    name: "MUHAMMAD SHAYAN",
    job: "Property Consultant",
    img: "https://res.cloudinary.com/dkc5klynm/image/upload/v1742557437/Sawani_Website-21_a4qqxj.webp",
    moreInformation: "Property Consultant"
  }
];


function TeamMemberTableData({ setOpenDelete, onView, onEdit }) {
  const headers = [
    {
      label: "Name",
      dataIndex: "name",
      sort: true,
      search: true,
    },
    {
      label: "Image",
      render: ({ row }) => (
        <img src={row.img} alt="" className="w-32 h-auto" />
      ),
      sort: false,
      search: false,
    },
    {
      label: "Role",
      dataIndex: "job",
      sort: true,
      search: true,
    },
    {
      label: "Actions",
      render: ({ row }) => (
        <div className="flex gap-2">
          <button
            onClick={() => onView(row)}
            className="bg-green-500 text-white py-1 px-3 rounded hover:bg-green-600 transition"
          >
            View
          </button>
          <button
            onClick={() => onEdit(row)}
            className="bg-blue-500 text-white py-1 px-3 rounded hover:bg-blue-600 transition"
          >
            Edit
          </button>
          <button
            onClick={() => setOpenDelete(row)}
            className="bg-red-500 text-white py-1 px-3 rounded hover:bg-red-600 transition"
          >
            Delete
          </button>
        </div>
      ),
      sort: false,
      search: false,
    },
  ];

  return (
    <div className="TeamMemberTableData">
      <Table title={"Team Members Data"} headers={headers} body={teamMembers} />
    </div>
  );
}

export default TeamMemberTableData;
