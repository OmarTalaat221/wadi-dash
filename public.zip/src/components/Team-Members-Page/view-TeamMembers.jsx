import React from "react";
import { BsArrowLeft } from "react-icons/bs";

function ViewTeamMember({ teamMember, onBack }) {
  return (
    <div className="p-8 bg-white rounded-lg shadow-lg">
     
      <div className="mb-4 flex items-center">
      <button
        onClick={onBack}
        className="bg-blue-500 text-white mx-1 py-2 px-4 rounded hover:bg-blue-600 transition"
      >
        <BsArrowLeft />
      </button>
        <span className="font-semibold">Name: </span>
        {teamMember.name}
      </div>
      <div className="mb-4">
        <img src={teamMember.img} alt="" className="w-full max-w-md" />
      </div>
      <div className="mb-4">
        <span className="font-semibold">Role: </span>
        {teamMember.job}
      </div>
      <div className="mb-4">
        <span className="font-semibold">More Information: </span>
        {teamMember.moreInformation}
      </div>
    </div>
  );
}

export default ViewTeamMember;
