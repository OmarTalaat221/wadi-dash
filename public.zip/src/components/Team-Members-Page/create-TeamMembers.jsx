import React from "react";

function CreateTeamMember({ onBack }) {
  return (
    <div className="p-8 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Create New TeamMember</h2>
      <form className="space-y-4">
        <div>
          <label className="block text-gray-700 font-semibold">Image</label>
          <input
            type="file"
            placeholder="Team Member Image"
            className="border px-3 py-2 rounded w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 font-semibold">Name</label>
          <input
            type="text"
            placeholder="Waseem Sawani"
            className="border px-3 py-2 rounded w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 font-semibold">Role</label>
          <input
            type="text"
            placeholder="CEO. Founder"
            className="border px-3 py-2 rounded w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 font-semibold">More Information</label>
          <textarea
            placeholder="Enter more information here..."
            rows="4"
            className="border px-3 py-2 rounded w-full"
          ></textarea>
        </div>
        <div className="flex gap-4">
          <button type="submit" className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 transition">
            Create
          </button>
          <button type="button" onClick={onBack} className="bg-gray-500 text-white py-2 px-4 rounded hover:bg-gray-600 transition">
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}

export default CreateTeamMember;
