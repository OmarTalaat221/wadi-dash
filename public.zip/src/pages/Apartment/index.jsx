import React, { useState } from "react";
import BreadCrumbs from "../../components/bread-crumbs";
import ApartmentTableData from "../../components/Apartment-Page/Apartment-table-data";
import ConfirmDeleteApartment from "../../components/Apartment-Page/confirm-delete";
import ViewApartment from "../../components/Apartment-Page/view-apartment";
import EditApartment from "../../components/Apartment-Page/edit-apartment";
import CreateApartment from "../../components/Apartment-Page/create-apartment";

function Apartment() {
  const [openDelete, setOpenDelete] = useState(false);
  const [activeTab, setActiveTab] = useState("table"); // "table", "view", "edit", "create"
  const [selectedApartment, setSelectedApartment] = useState(null);

  const handleView = (apartment) => {
    setSelectedApartment(apartment);
    setActiveTab("view");
  };

  const handleEdit = (apartment) => {
    setSelectedApartment(apartment);
    setActiveTab("edit");
  };

  const handleCreate = () => {
    setSelectedApartment(null);
    setActiveTab("create");
  };

  return (
    <div className="flex flex-col p-4 ">
      <BreadCrumbs
        title={"Dashboard / Home / Apartment Videos"}
        children={
          <>
            {" "}
            <button
              onClick={handleCreate}
              class="inline-flex items-center bg-[#295557] hover:bg-[#64401ad8] text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-[#64401ad4]"
            >
              <svg
                class="w-5 h-5 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M12 4v16m8-8H4"
                ></path>
              </svg>
              Create New
            </button>
          </>
        }
      />
      <div className=" mt-4">
        {activeTab === "table" && (
          <div className="TableData">
            <ApartmentTableData
              setOpenDelete={setOpenDelete}
              onView={handleView}
              onEdit={handleEdit}
            />
            <ConfirmDeleteApartment open={openDelete} setOpen={setOpenDelete} />
          </div>
        )}
        {activeTab === "view" && selectedApartment && (
          <ViewApartment
            apartment={selectedApartment}
            onBack={() => setActiveTab("table")}
          />
        )}
        {activeTab === "edit" && selectedApartment && (
          <EditApartment
            apartment={selectedApartment}
            onBack={() => setActiveTab("table")}
          />
        )}
        {activeTab === "create" && (
          <CreateApartment onBack={() => setActiveTab("table")} />
        )}
      </div>
    </div>
  );
}

export default Apartment;
