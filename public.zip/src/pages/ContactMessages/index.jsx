import React, { useState } from "react";
import BreadCrumbs from "../../components/bread-crumbs";
import TourBreadcrumbsButtons from "../../components/tours-page/tour-breadcrumbs-buttons";
import ToursTableData from "../../components/tours-page/tour-table-data";
import Modal from "../../components/modal";
import ImportToursExcel from "../../components/tours-page/import-excel-modal";
import ConfirmDeleteTour from "../../components/tours-page/confirm-delete";
import { tours } from "../../data/tours";
import ContactMessagesTableData from "../../components/contact-page/contact-table-data";
import ConfirmDeleteMessage from "../../components/contact-page/confirm-delete";

function ContactMessages() {
  const [openImport, setOpenImport] = useState(false);
  const [openDelete, setOpenDelete] = useState(false);

  return (
    <div className="flex flex-col">
      <BreadCrumbs title={"Dashboard / Home / Messages"} children={<></>} />
      <ContactMessagesTableData setOpenDelete={setOpenDelete} />

      <ConfirmDeleteMessage open={openDelete} setOpen={setOpenDelete} />
    </div>
  );
}

export default ContactMessages;
