import React, { useState } from "react";
import BreadCrumbs from "../../components/bread-crumbs";
import ConfirmDeleteTeamMembers from "../../components/Team-Members-Page/confirm-delete";
import CreateTeamMember from "../../components/Team-Members-Page/create-TeamMembers";
import EditTeamMember from "../../components/Team-Members-Page/edit-TeamMembers";
import TeamMemberTableData from "../../components/Team-Members-Page/TeamMembers-table-data";
import ViewTeamMember from "../../components/Team-Members-Page/view-TeamMembers";

function TeamMembers() {
  const [openDelete, setOpenDelete] = useState(false);
  const [activeTab, setActiveTab] = useState("table"); // "table", "view", "edit", "create"
  const [selectedTeamMember, setSelectedTeamMember] = useState(null);

  const handleView = (teamMember) => {
    setSelectedTeamMember(teamMember);
    setActiveTab("view");
  };

  const handleEdit = (teamMember) => {
    setSelectedTeamMember(teamMember);
    setActiveTab("edit");
  };

  const handleCreate = () => {
    setSelectedTeamMember(null);
    setActiveTab("create");
  };

  return (
    <div className="flex flex-col p-4 ">
      <BreadCrumbs
        title={"Dashboard / Home / Team Members"}
        children={
          <>
            {" "}
            <button
              onClick={handleCreate}
              class="inline-flex items-center bg-[#295557] hover:bg-[#64401ad8] text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-[#64401ad4]"
            >
              <svg
                class="w-5 h-5 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M12 4v16m8-8H4"
                ></path>
              </svg>
              Create New
            </button>
          </>
        }
      />
      <div className=" mt-4">
        {activeTab === "table" && (
          <div className="TableData">
            <TeamMemberTableData
              setOpenDelete={setOpenDelete}
              onView={handleView}
              onEdit={handleEdit}
            />
            <ConfirmDeleteTeamMembers
              open={openDelete}
              setOpen={setOpenDelete}
            />
          </div>
        )}
        {activeTab === "view" && selectedTeamMember && (
          <ViewTeamMember
            teamMember={selectedTeamMember}
            onBack={() => setActiveTab("table")}
          />
        )}
        {activeTab === "edit" && selectedTeamMember && (
          <EditTeamMember
            teamMember={selectedTeamMember}
            onBack={() => setActiveTab("table")}
          />
        )}
        {activeTab === "create" && (
          <CreateTeamMember onBack={() => setActiveTab("table")} />
        )}
      </div>
    </div>
  );
}

export default TeamMembers;
