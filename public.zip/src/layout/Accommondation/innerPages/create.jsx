import React, { useState, useRef } from "react";
import Tabs from "../../../components/Tabs";

function CreateAccomLayout() {
  const [productData, setProductData] = useState({
    propertyInfo: {
      Type: "",
      Purpose: "",
      "Reference no.": "",
      Completion: "",
      Furnishing: "",
      "Handover date": "",
    },
  });
  const initialFeatures = (productData.features || []).map((feat) =>
    feat.label !== undefined && feat.value !== undefined
      ? feat
      : (() => {
          const parts = feat.text.split(":");
          const label = parts[0]?.trim() || "";
          const value = parts[1]?.trim() || "";
          return { icon: null, label, value };
        })()
  );
  const initialImages = (productData.images || []).map((img) => ({
    type: "url",
    value: img,
  }));
  const initialFloorPlans = (productData.floorPlans || []).map((fp) => ({
    type: "url",
    value: fp,
  }));
  const [formData, setFormData] = useState({
    ...productData,
    features: initialFeatures,
    images: initialImages,
    floorPlans: initialFloorPlans,
  });
  const [activeTab, setActiveTab] = useState("General");
  const imageInputRef = useRef(null);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  const handlePropertyChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      propertyInfo: { ...prev.propertyInfo, [name]: value },
    }));
  };
  const handleFeatureFieldChange = (index, field, value) => {
    const updatedFeatures = [...formData.features];
    updatedFeatures[index] = { ...updatedFeatures[index], [field]: value };
    setFormData((prev) => ({ ...prev, features: updatedFeatures }));
  };
  const handleFeatureIconChange = (index, file) => {
    const updatedFeatures = [...formData.features];
    updatedFeatures[index] = { ...updatedFeatures[index], icon: file };
    setFormData((prev) => ({ ...prev, features: updatedFeatures }));
  };
  const removeFeature = (index) => {
    setFormData((prev) => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index),
    }));
  };
  const addFeature = () => {
    setFormData((prev) => ({
      ...prev,
      features: [...prev.features, { icon: null, label: "", value: "" }],
    }));
  };
  const triggerImageFileInput = () => {
    if (imageInputRef.current) imageInputRef.current.click();
  };
  const handleImageFilesChange = (files) => {
    const fileArray = Array.from(files).map((file) => ({
      type: "file",
      file,
      value: file.name,
      preview: URL.createObjectURL(file),
    }));
    setFormData((prev) => ({
      ...prev,
      images: [...prev.images, ...fileArray],
    }));
  };
  const removeImage = (index) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }));
  };
  const handleFloorPlanTypeChange = (index, newType) => {
    const updatedFloorPlans = [...formData.floorPlans];
    updatedFloorPlans[index] = { type: newType, value: "" };
    setFormData((prev) => ({ ...prev, floorPlans: updatedFloorPlans }));
  };
  const handleFloorPlanValueChange = (index, value) => {
    const updatedFloorPlans = [...formData.floorPlans];
    updatedFloorPlans[index] = { ...updatedFloorPlans[index], value };
    setFormData((prev) => ({ ...prev, floorPlans: updatedFloorPlans }));
  };
  const handleFloorPlanFileChange = (index, file) => {
    const updatedFloorPlans = [...formData.floorPlans];
    updatedFloorPlans[index] = {
      ...updatedFloorPlans[index],
      file,
      value: file.name,
      preview: URL.createObjectURL(file),
    };
    setFormData((prev) => ({ ...prev, floorPlans: updatedFloorPlans }));
  };
  const removeFloorPlan = (index) => {
    setFormData((prev) => ({
      ...prev,
      floorPlans: prev.floorPlans.filter((_, i) => i !== index),
    }));
  };
  const addFloorPlan = () => {
    setFormData((prev) => ({
      ...prev,
      floorPlans: [...prev.floorPlans, { type: "url", value: "" }],
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Created tour:", formData);
  };
  const renderTabContent = () => {
    if (activeTab === "General") {
      return (
        <>
          <div>
            <label className="block !mb-1 font-medium">Title</label>
            <input
              type="text"
              name="title"
              value={formData.title || ""}
              onChange={handleChange}
              className="w-full !border border-gray-300 !p-2 rounded"
            />
          </div>

          <div>
            <label className="block mb-1 font-medium">Description</label>
            <textarea
              name="description"
              value={formData.description || ""}
              onChange={handleChange}
              rows="6"
              className="w-full border border-gray-300 p-2 rounded"
            ></textarea>
          </div>
        </>
      );
    }

    if (activeTab === "Features") {
      return (
        <fieldset className="border p-4 rounded">
          <legend className="font-medium mb-2">Features</legend>
          <div className="flex flex-wrap gap-3 m-auto">
            {formData.features.map((feature, index) => (
              <div
                key={index}
                className="mb-3 space-y-2 w-[340px] border p-2 rounded"
              >
                <div className="flex items-center space-x-2">
                  <span className="w-16">Icon:</span>
                  <input
                    type="file"
                    onChange={(e) =>
                      handleFeatureIconChange(
                        index,
                        e.target.files ? e.target.files[0] : null
                      )
                    }
                    className="w-full"
                  />
                  {feature.icon && (
                    <span className="text-sm text-gray-600">
                      {feature.icon.name || "File selected"}
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <label className="w-16">Label:</label>
                  <input
                    type="text"
                    value={feature.label}
                    onChange={(e) =>
                      handleFeatureFieldChange(index, "label", e.target.value)
                    }
                    className="w-full border border-gray-300 p-2 rounded"
                    placeholder="Feature Label"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <label className="w-16">Value:</label>
                  <input
                    type="text"
                    value={feature.value}
                    onChange={(e) =>
                      handleFeatureFieldChange(index, "value", e.target.value)
                    }
                    className="w-full border border-gray-300 p-2 rounded"
                    placeholder="Feature Value"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => removeFeature(index)}
                  className="bg-red-500 text-white py-1 px-3 rounded hover:bg-red-600 transition-colors duration-200"
                >
                  Remove Feature
                </button>
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={addFeature}
            className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 transition-colors duration-200"
          >
            Add Feature
          </button>
        </fieldset>
      );
    }
    if (activeTab === "Images") {
      return (
        <fieldset className="border p-4 rounded">
          <legend className="font-medium mb-2">Images</legend>
          <div className="space-y-2">
            <div className="flex flex-wrap gap-3 m-auto">
              {formData.images.map((img, index) => (
                <div key={index} className="flex items-center space-x-2">
                  {img.type === "file" && img.preview ? (
                    <img
                      src={img.preview}
                      alt="Preview"
                      className="w-16 h-16 object-cover"
                    />
                  ) : (
                    <img
                      src={img.value}
                      alt="Preview"
                      className="w-16 h-16 object-cover"
                    />
                  )}
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="bg-red-500 text-white py-1 px-3 rounded hover:bg-red-600 transition-colors duration-200"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
            <div className="mt-2">
              <button
                type="button"
                onClick={triggerImageFileInput}
                className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 transition-colors duration-200"
              >
                Add Images
              </button>
              <input
                type="file"
                multiple
                ref={imageInputRef}
                onChange={(e) => {
                  if (e.target.files) handleImageFilesChange(e.target.files);
                }}
                className="hidden"
              />
            </div>
          </div>
        </fieldset>
      );
    }
  };
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Create Accommondation</h1>
      <div className="mb-4">
        <nav className="flex justify-between items-center gap-0.5 w-[100%]">
          <Tabs
            tabs={["General", "Features", "Images"]}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
          />
          <button
            type="submit"
            className="bg-blue-500 text-white !py-2 !px-4 rounded hover:bg-blue-600 transition-colors duration-200"
          >
            Create Accommondation
          </button>
        </nav>
      </div>
      <form
        onSubmit={handleSubmit}
        className="space-y-6 bg-white !p-5 rounded-[10px]"
      >
        {renderTabContent()}
      </form>
    </div>
  );
}

export default CreateAccomLayout;
