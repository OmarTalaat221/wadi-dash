export const tours = [
  {
    id: 1,
    url: "https://www.bayut.com/property/details-9774917.html",
    title: "Travelling To Egypt",

    description:
      'Sawani Properties is proud to present the newly launched apartments in "Alef Noon Residence," located in JVC. Discover unparalleled luxury living at Alef Noon Residence, featuring premium studios, 1 & 2-bedroom apartments. Developed with basement parking, multiple parking floors, and a ground plus 8-storey structure, this architectural marvel comprises 165 modern luxury apartments, complemented by high-end facilities and services. With a contemporary design and state-of-the-art amenities, it promises a lifestyle of comfort, convenience, and sophistication for its residents. \nPayment Plan Options: 2-Year Payment Plan\nProperty Details & Features:\n\n\nSpacious 2 Bedroom\nMaids room/study room\n3 Bathrooms\nBalcony\nBBQ zone by Weber\nYoga area\nInfinity pool + Children\'s pool\nGymnasium\nSauna\nChillout Zone with Fountains\nPrivate Garden\nWater Cooling System in the apartments\nElectric Vehicle Charging Stations\nLobby with co-working and meeting zones\nPublic WiFi\n\n\n\nFor more information, contact Ms. Michaela Kim: View Contact Detail.',

    features: [
      {
        text: "Free cancellation",
        icon: '\u003Cuse xlink:href="/assets/iconAmenities_noinline.1dd3ec62fde7eeadd6150da864cd04c1.svg#parking-spaces"\u003E\u003C/use\u003E',
      },
      {
        text: "Perfect travel plan",
        icon: '\u003Cuse xlink:href="/assets/iconAmenities_noinline.1dd3ec62fde7eeadd6150da864cd04c1.svg#central-air-con"\u003E\u003C/use\u003E',
      },
      {
        text: "Fully customizable",
        icon: '\u003Cuse xlink:href="/assets/iconAmenities_noinline.1dd3ec62fde7eeadd6150da864cd04c1.svg#study-room"\u003E\u003C/use\u003E',
      },
      {
        text: "24/7 customer support",
        icon: '\u003Cuse xlink:href="/assets/iconAmenities_noinline.1dd3ec62fde7eeadd6150da864cd04c1.svg#balcony-or-terrace"\u003E\u003C/use\u003E',
      },
    ],

    images: [
      "https://res.cloudinary.com/dkc5klynm/image/upload/v1744642054/Egypt-54_e1e42f.jpg",
      "https://images.bayut.com/thumbnails/764214768-800x600.jpeg",
      "https://images.bayut.com/thumbnails/764214769-800x600.jpeg",
      "https://images.bayut.com/thumbnails/764214770-800x600.jpeg",
      "https://images.bayut.com/thumbnails/764214777-800x600.jpeg",
      "https://images.bayut.com/thumbnails/764214778-800x600.jpeg",
      "https://images.bayut.com/thumbnails/764214779-800x600.jpeg",
      "https://images.bayut.com/thumbnails/764214780-800x600.jpeg",
      "https://images.bayut.com/thumbnails/764214781-800x600.jpeg",
      "https://images.bayut.com/thumbnails/764214789-800x600.jpeg",
      "https://images.bayut.com/thumbnails/764214790-800x600.jpeg",
    ],
    floorPlans: [],
    map: `https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d54839.27303659022!2d30.965215034423952!3d30.789884409075785!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14f7c972726f94b3%3A0x6b152b6e2644fdc8!2sSecond%20Tanta%2C%20Gharbia%20Governorate!5e0!3m2!1sen!2seg!4v1745057388239!5m2!1sen!2seg`,
    jsonLd: [
      {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        itemListElement: [
          {
            "@type": "ListItem",
            name: "Dubai Apartments",
            position: 1,
            item: "https://www.bayut.com/for-sale/apartments/dubai/",
          },
          {
            "@type": "ListItem",
            name: "Jumeirah Village Circle (JVC)",
            position: 2,
            item: "https://www.bayut.com/for-sale/apartments/dubai/jumeirah-village-circle-jvc/",
          },
          {
            "@type": "ListItem",
            name: "JVC District 16",
            position: 3,
            item: "https://www.bayut.com/for-sale/apartments/dubai/jumeirah-village-circle-jvc/jvc-district-16/",
          },
          {
            "@type": "ListItem",
            name: "Alef Noon Residence",
            position: 4,
            item: "https://www.bayut.com/for-sale/apartments/dubai/jumeirah-village-circle-jvc/jvc-district-16/alef-noon-residence/",
          },
          {
            "@type": "ListItem",
            name: "Bayut - 6075-ANR-WS-002",
            position: 5,
          },
        ],
      },
      {
        "@context": "https://schema.org",
        "@type": "ItemPage",
        mainEntity: {
          "@type": "Tour",
          name: "High ROI  | Spacious unit | 2-Year Post Handover Plan",
          url: "https://www.bayut.com/property/details-9774917.html",
          alternateName: "2 Bedroom Apartment For Sale in Alef Noon Residence",
          description:
            'Sawani Properties is proud to present the newly launched apartments in "Alef Noon Residence," located in JVC. Discover unparalleled luxury living at Alef Noon Residence, featuring premium studios, 1 & 2-bedroom apartments. Developed with basement parking, multiple parking floors, and a ground plus 8-storey structure, this architectural marvel comprises 165 modern luxury apartments, complemented by high-end facilities and services. With a contemporary design and state-of-the-art amenities, it promises a lifestyle of comfort, convenience, and sophistication for its residents. Payment Plan Options: 2-Year Payment PlanProperty Details & Features:Spacious 2 BedroomMaids room/study room3 BathroomsBalconyBBQ zone by WeberYoga areaInfinity pool + Children\'s poolGymnasiumSaunaChillout Zone with FountainsPrivate GardenWater Cooling System in the apartmentsElectric Vehicle Charging StationsLobby with co-working and meeting zonesPublic WiFiFor more information, contact Ms. Michaela Kim: [redacted phone number]. ',
          image: "https://images.bayut.com/thumbnails/764214768-800x600.jpeg",
          offers: [
            {
              "@type": "Offer",
              priceCurrency: "AED",
              url: "https://www.bayut.com/property/details-9774917.html",
              priceSpecification: {
                "@type": "UnitPriceSpecification",
                price: 1563188,
                priceCurrency: "AED",
              },
              offeredBy: {
                "@type": "RealEstateAgent",
                name: "Michaela Kim",
                image:
                  "https://images.bayut.com/thumbnails/27681178-240x180.jpeg",
                parentOrganization: {
                  "@type": "Organization",
                  name: "Sawani Properties",
                  url: "https://www.bayut.com/companies/sawani-properties-6075/",
                },
              },
            },
          ],
        },
      },
      {
        "@context": "https://schema.org",
        "@type": "Apartment",
        name: "High ROI  | Spacious unit | 2-Year Post Handover Plan",
        url: "https://www.bayut.com/property/details-9774917.html",
        alternateName: "2 Bedroom Apartment For Sale in Alef Noon Residence",
        geo: {
          "@type": "GeoCoordinates",
          latitude: 25.068960521174,
          longitude: 55.209032485946,
        },
        floorSize: {
          "@type": "QuantitativeValue",
          value: "1,251",
          unitText: "SQFT",
        },
        numberOfRooms: {
          "@type": "QuantitativeValue",
          name: "Bedroom(s)",
          value: "2",
        },
        numberOfBathroomsTotal: "3",
        image: "https://images.bayut.com/thumbnails/764214768-800x600.jpeg",
        address: {
          "@type": "PostalAddress",
          addressCountry: "UAE",
          addressRegion: "Dubai",
          addressLocality: "Jumeirah Village Circle (JVC)",
        },
        containedInPlace: {
          "@type": "Place",
          name: "Jumeirah Village Circle (JVC)",
          url: "https://www.bayut.com/for-sale/apartments/dubai/jumeirah-village-circle-jvc/",
        },
      },
      {
        "@context": "https://schema.org",
        "@type": "Apartment",
        name: "Fully Furnished plus Study Room | High Floor",
        url: "https://www.bayut.com/property/details-10986289.html",
        geo: {
          "@type": "GeoCoordinates",
          latitude: 25.067733,
          longitude: 55.214925,
        },
        floorSize: {
          "@type": "QuantitativeValue",
          value: "1,146",
          unitText: "SQFT",
        },
        numberOfRooms: {
          "@type": "QuantitativeValue",
          name: "Bedroom(s)",
          value: "2",
        },
        numberOfBathroomsTotal: "3",
        image: "https://images.bayut.com/thumbnails/762728907-400x300.jpeg",
        address: {
          "@type": "PostalAddress",
          addressCountry: "UAE",
          addressRegion: "Dubai",
          addressLocality: "Jumeirah Village Circle (JVC)",
        },
      },
      {
        "@context": "https://schema.org",
        "@type": "Apartment",
        name: "Invest Wisely: Exquisite 2BHK + Maid with Top ROI Potential I High Return",
        url: "https://www.bayut.com/property/details-11290479.html",
        geo: {
          "@type": "GeoCoordinates",
          latitude: 25.059794823586,
          longitude: 55.208279009969,
        },
        floorSize: {
          "@type": "QuantitativeValue",
          value: "1,190",
          unitText: "SQFT",
        },
        numberOfRooms: {
          "@type": "QuantitativeValue",
          name: "Bedroom(s)",
          value: "2",
        },
        numberOfBathroomsTotal: "3",
        image: "https://images.bayut.com/thumbnails/767998977-400x300.jpeg",
        address: {
          "@type": "PostalAddress",
          addressCountry: "UAE",
          addressRegion: "Dubai",
          addressLocality: "Jumeirah Village Circle (JVC)",
        },
      },
      {
        "@context": "https://schema.org",
        "@type": "Apartment",
        name: "Vastu North East | Hot Unit | Exclusive",
        url: "https://www.bayut.com/property/details-11281253.html",
        geo: {
          "@type": "GeoCoordinates",
          latitude: 25.063191261888,
          longitude: 55.212502599475,
        },
        floorSize: {
          "@type": "QuantitativeValue",
          value: "1,178",
          unitText: "SQFT",
        },
        numberOfRooms: {
          "@type": "QuantitativeValue",
          name: "Bedroom(s)",
          value: "2",
        },
        numberOfBathroomsTotal: "3",
        image: "https://images.bayut.com/thumbnails/767832228-400x300.jpeg",
        address: {
          "@type": "PostalAddress",
          addressCountry: "UAE",
          addressRegion: "Dubai",
          addressLocality: "Jumeirah Village Circle (JVC)",
        },
      },
    ],
  },
  {
    id: 2,
    url: "https://www.bayut.com/property/details-6596953.html",
    title: "Travelling To Iceland",

    description:
      "Sawani Properties is delighted to offer you this 1-bedroom apartment for rent in AG Tower, Business Bay, Dubai. \n\nAG Tower Dubai is located in the heart of Business Bay and offers many amenities. \n\nAG Tower UAE has easy access to Burj Khalifa, DIFC, The Dubai Mall, Meydan, Downtown Dubai, and other destinations in the neighborhood. It is also close to Al Khail, Sheikh Zayed Road, and the Dubai Water Canal. \n\nProperty Details:\n01 Bedroom Apt\n1.5 Bathrooms\nUnfurnished Apt\nSize: 895.88sqft. \nfitted wardrobes\nSpacious balcony\nCanal View\n1 Covered Parking\n\nBuilding Amenities:\nChildren play area\nLuxurious swimming pool and gym\n24-hour security\nHi-speed elevators\nConcierge services\nLandscaped gardens\n\nFor more details and viewings, please get in touch with Mr. Khizer Hayat: View Contact Detail.",

    features: [
      {
        text: "Free cancellation",
        icon: '\u003Cuse xlink:href="/assets/iconAmenities_noinline.1dd3ec62fde7eeadd6150da864cd04c1.svg#parking-spaces"\u003E\u003C/use\u003E',
      },
      {
        text: "Perfect travel plan",
        icon: '\u003Cuse xlink:href="/assets/iconAmenities_noinline.1dd3ec62fde7eeadd6150da864cd04c1.svg#central-air-con"\u003E\u003C/use\u003E',
      },
      {
        text: "Fully customizable",
        icon: '\u003Cuse xlink:href="/assets/iconAmenities_noinline.1dd3ec62fde7eeadd6150da864cd04c1.svg#study-room"\u003E\u003C/use\u003E',
      },
      {
        text: "24/7 customer support",
        icon: '\u003Cuse xlink:href="/assets/iconAmenities_noinline.1dd3ec62fde7eeadd6150da864cd04c1.svg#balcony-or-terrace"\u003E\u003C/use\u003E',
      },
    ],

    images: [
      "https://gti.images.tshiftcdn.com/7985421/x/0/6-day-northern-lights-adventure-package-in-iceland-with-ice-caving.jpg?w=360&h=220&fit=crop&crop=center&auto=format%2Ccompress&q=32&dpr=2&ixlib=react-9.8.1",
      "https://images.bayut.com/thumbnails/315578893-800x600.jpeg",
      "https://images.bayut.com/thumbnails/315591590-800x600.jpeg",
      "https://images.bayut.com/thumbnails/315591589-800x600.jpeg",
      "https://images.bayut.com/thumbnails/324022759-800x600.jpeg",

      "https://images.bayut.com/thumbnails/745830615-800x600.jpeg",
    ],
    floorPlans: [],
    map: `https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d54839.27303659022!2d30.965215034423952!3d30.789884409075785!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14f7c972726f94b3%3A0x6b152b6e2644fdc8!2sSecond%20Tanta%2C%20Gharbia%20Governorate!5e0!3m2!1sen!2seg!4v1745057388239!5m2!1sen!2seg`,
    jsonLd: [
      {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        itemListElement: [
          {
            "@type": "ListItem",
            name: "Dubai Apartments",
            position: 1,
            item: "https://www.bayut.com/to-rent/apartments/dubai/",
          },
          {
            "@type": "ListItem",
            name: "Business Bay",
            position: 2,
            item: "https://www.bayut.com/to-rent/apartments/dubai/business-bay/",
          },
          {
            "@type": "ListItem",
            name: "AG Tower",
            position: 3,
            item: "https://www.bayut.com/to-rent/apartments/dubai/business-bay/ag-tower-/",
          },
          {
            "@type": "ListItem",
            name: "Bayut - SP-RT-00023",
            position: 4,
          },
        ],
      },
      {
        "@context": "https://schema.org",
        "@type": "ItemPage",
        mainEntity: {
          "@type": "Tour",
          name: "Huge| Unfurnished | Canal View| BBay | 1Bhk | Rent",
          url: "https://www.bayut.com/property/details-6596953.html",
          alternateName: "1 Bedroom Apartment For Rent in AG Tower",
          description:
            "Sawani Properties is delighted to offer you this 1-bedroom apartment for rent in AG Tower, Business Bay, Dubai. AG Tower Dubai is located in the heart of Business Bay and offers many amenities. AG Tower UAE has easy access to Burj Khalifa, DIFC, The Dubai Mall, Meydan, Downtown Dubai, and other destinations in the neighborhood. It is also close to Al Khail, Sheikh Zayed Road, and the Dubai Water Canal. Property Details:01 Bedroom Apt1.5 BathroomsUnfurnished AptSize: 895.88sqft. fitted wardrobesSpacious balconyCanal View1 Covered ParkingBuilding Amenities:Children play areaLuxurious swimming pool and gym24-hour securityHi-speed elevatorsConcierge servicesLandscaped gardensFor more details and viewings, please get in touch with Mr. Khizer Hayat: [redacted phone number].",
          image: "https://images.bayut.com/thumbnails/315578893-800x600.jpeg",
          offers: [
            {
              "@type": "Offer",
              priceCurrency: "AED",
              url: "https://www.bayut.com/property/details-6596953.html",
              businessFunction: "http://purl.org/goodrelations/v1#LeaseOut",
              priceSpecification: {
                "@type": "UnitPriceSpecification",
                price: 79999,
                priceCurrency: "AED",
                unitText: "yearly",
              },
              offeredBy: {
                "@type": "RealEstateAgent",
                name: "Khizer Hayat",
                image:
                  "https://images.bayut.com/thumbnails/27681178-240x180.jpeg",
                parentOrganization: {
                  "@type": "Organization",
                  name: "Sawani Properties",
                  url: "https://www.bayut.com/companies/sawani-properties-6075/",
                },
              },
            },
          ],
        },
      },
      {
        "@context": "https://schema.org",
        "@type": "Apartment",
        name: "Huge| Unfurnished | Canal View| BBay | 1Bhk | Rent",
        url: "https://www.bayut.com/property/details-6596953.html",
        alternateName: "1 Bedroom Apartment For Rent in AG Tower",
        numberOfBathroomsTotal: "2",
        image: "https://images.bayut.com/thumbnails/315578893-800x600.jpeg",
      },
      {
        "@context": "https://schema.org",
        "@type": "House",
        name: "3BR Fully Furnished | Opposite to Pool | R2EM",
        url: "https://www.bayut.com/property/details-11221234.html",

        floorSize: {
          "@type": "QuantitativeValue",
          value: "1,881",
          unitText: "SQFT",
        },
        numberOfRooms: {
          "@type": "QuantitativeValue",
          name: "Bedroom(s)",
          value: "3",
        },
        numberOfBathroomsTotal: "4",
        image: "https://images.bayut.com/thumbnails/766829676-400x300.jpeg",
        address: {
          "@type": "PostalAddress",
          addressCountry: "UAE",
          addressRegion: "Dubai",
          addressLocality: "DAMAC Hills 2 (Akoya by DAMAC)",
        },
      },
      {
        "@context": "https://schema.org",
        "@type": "House",
        name: "Premium Location |Community View | End-Middle Type",
        url: "https://www.bayut.com/property/details-11148158.html",
        geo: {
          "@type": "GeoCoordinates",
          latitude: 24.979912012474,
          longitude: 55.380280432386,
        },
        floorSize: {
          "@type": "QuantitativeValue",
          value: "1,802",
          unitText: "SQFT",
        },
        numberOfRooms: {
          "@type": "QuantitativeValue",
          name: "Bedroom(s)",
          value: "3",
        },
        numberOfBathroomsTotal: "3",
        image: "https://images.bayut.com/thumbnails/765584728-400x300.jpeg",
        address: {
          "@type": "PostalAddress",
          addressCountry: "UAE",
          addressRegion: "Dubai",
          addressLocality: "DAMAC Hills 2 (Akoya by DAMAC)",
        },
      },
      {
        "@context": "https://schema.org",
        "@type": "House",
        name: "READY TO MOVE IN | SPACIOUS WITH GARDEN | EXCLUSIVE",
        url: "https://www.bayut.com/property/details-9971944.html",
        geo: {
          "@type": "GeoCoordinates",
          latitude: 24.978977101447,
          longitude: 55.383677413126,
        },
        floorSize: {
          "@type": "QuantitativeValue",
          value: "1,901",
          unitText: "SQFT",
        },
        numberOfRooms: {
          "@type": "QuantitativeValue",
          name: "Bedroom(s)",
          value: "3",
        },
        numberOfBathroomsTotal: "3",
        image: "https://images.bayut.com/thumbnails/759473267-400x300.jpeg",
        address: {
          "@type": "PostalAddress",
          addressCountry: "UAE",
          addressRegion: "Dubai",
          addressLocality: "DAMAC Hills 2 (Akoya by DAMAC)",
        },
      },
    ],
  },
];
