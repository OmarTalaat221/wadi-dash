import Apartment from "../pages/Apartment";
import Banners from "../pages/banners";
import ContactMessages from "../pages/ContactMessages";
import Home from "../pages/home";
import Login from "../pages/login";

import TeamMembers from "../pages/Team-Members";
import WebsiteInformation from "../pages/website-information";
import Tours from "../pages/tours";
import CreateTour from "../pages/tours/innerPages/create";
import UpdateTour from "../pages/tours/innerPages/update";
import { PiBuildingApartment } from "react-icons/pi";
import Accommodation from "../pages/Accommodation";
import CreateAccom from "../pages/Accommodation/innerPages/create";
import UpdateAccom from "../pages/Accommodation/innerPages/update";

export const publicRoutes = [
  {
    title: "Dashboard",
    icon: "/space_dashboard.svg",
    hidden: false,
    route: "*",
    element: Home,
  },
  {
    title: "Tours",
    icon: "/Product.svg",
    hidden: false,
    route: "/tours",
    element: Tours,
    subLinks: [
      {
        title: "Create",
        icon: "/plus.png",
        hidden: false,
        route: "create",
        element: CreateTour,
      },

      {
        title: "Update",
        icon: "/edit.png",
        hidden: true,
        route: "update/:product_id",
        element: UpdateTour,
      },
    ],
  },
  {
    title: "Banners",
    icon: "/Banners.jpg",
    hidden: false,
    route: "/Banners",
    element: Banners,
  },
  {
    title: "Accommodation",
    icon: PiBuildingApartment,
    hidden: false,
    route: "/accommodation",
    element: Accommodation,
    subLinks: [
      {
        title: "Create",
        icon: "/plus.png",
        hidden: false,
        route: "create",
        element: CreateAccom,
      },
      {
        title: "Update",
        icon: "/edit.png",
        hidden: true,
        route: "update/:product_id",
        element: UpdateAccom,
      },
    ],
  },
  {
    title: "Website Information",
    icon: "/WebsiteInformation.png",
    hidden: false,
    route: "/WebsiteInformation",
    element: WebsiteInformation,
  },
  // {
  //   title: "Contact Messages",
  //   icon: "/ContactMessages.jpg",
  //   hidden: false,
  //   route: "/ContactMessages",
  //   element: ContactMessages,
  // },
  // {
  //   title: "Apartment",
  //   icon: "/Apartment.jpg",
  //   hidden: false,
  //   route: "/Apartment",
  //   element: Apartment,
  // },
  // {
  //   title: "TeamMembers",
  //   icon: "/TeamMembers.png",
  //   hidden: false,
  //   route: "/TeamMembers",
  //   element: TeamMembers,
  // },
];

export const authRoutes = [
  {
    title: "Login",
    icon: "",
    hidden: true,
    route: "*",
    element: Login,
  },
];
